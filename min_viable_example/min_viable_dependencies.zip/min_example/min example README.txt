Images from 
 People-Tracking-by-Detection and People-Detection-by-Tracking
 M. Andriluka, S. Roth, B. Schiele. People-Tracking-by-Detection and People-Detection-by-Tracking.
 IEEE Conf. on Computer Vision and Pattern Recognition (CVPR'08), Anchorage, USA, June 2008.
url:
https://www.mpi-inf.mpg.de/departments/computer-vision-and-multimodal-computing/research/people-detection-pose-estimation-and-tracking/people-tracking-by-detection-and-people-detection-by-tracking/#c5131

Rest and model for comparison by D.Panagopoulos
https://www.linkedin.com/in/dpanagopoulos/
https://github.com/dpanagop