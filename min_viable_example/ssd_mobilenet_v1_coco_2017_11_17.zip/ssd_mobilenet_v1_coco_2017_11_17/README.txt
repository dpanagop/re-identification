Model from
https://github.com/tensorflow/models
and adapted by D.Panagopoulos
https://www.linkedin.com/in/dpanagopoulos/
https://github.com/dpanagop